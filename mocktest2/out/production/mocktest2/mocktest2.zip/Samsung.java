import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

/**
 * Created by Khalin on 11/18/2016.
 */
public class Samsung extends CellularPhone{
    private float wapVersion;
    private String dataProtocol;

    public Samsung(){
        super();
        setWapVersion(0);
        setDataProtocol("LTE");
    }
    public Samsung(int inImei, String inModel,String inNetwork,float inWapVersion,String inDataProtocol){
        super(inImei,inModel,inNetwork);
        setWapVersion(inWapVersion);
        setDataProtocol(inDataProtocol);
    }
    public Samsung(Samsung samsung){
        super(samsung.getImei(),samsung.getModel(),samsung.getNetwork());
        setWapVersion(samsung.getWapVersion());
        setDataProtocol(samsung.getDataProtocol());
    }
    @Override
    public String toString(){
        String phone="";
        phone+=super.toString();
        phone+="Wap Version: "+getWapVersion()+"\n";
        phone+="Data Protocol: "+getDataProtocol()+"\n";
        return phone;
    }

    public float getWapVersion() {
        return wapVersion;
    }

    public void setWapVersion(float wapVersion) {
        this.wapVersion = wapVersion;
    }

    public String getDataProtocol() {
        return dataProtocol;
    }

    public void setDataProtocol(String dataProtocol) {
        this.dataProtocol = dataProtocol;
    }


    @Override
    public void writeToFile(){
        RandomAccessFile samsungFile=null;
        try {
            samsungFile= new RandomAccessFile(new File("samsung.txt"),"rw");
                try {
                    samsungFile.seek((getImei()-1)*recordSize());
                    samsungFile.writeInt(getImei());
                    samsungFile.writeUTF(getModel());
                    samsungFile.writeUTF(getNetwork());
                    samsungFile.writeFloat(getWapVersion());
                    samsungFile.writeUTF(getDataProtocol());
                } catch (IOException e) {
                    e.printStackTrace();
                }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }finally {
            try {
                samsungFile.close();
            }catch (IOException exc){
                //
            }
        }

    }
@Override
    public void initializeToFile() {
        RandomAccessFile samsungFile=null;
        try {
            samsungFile= new RandomAccessFile(new File("samsung.txt"),"rw");
            for(int count=1000; count<1020;count++){
                try {
                    samsungFile.seek((getImei()-1)*recordSize());
                    samsungFile.writeInt(getImei());
                    samsungFile.writeUTF(getModel());
                    samsungFile.writeUTF(getNetwork());
                    samsungFile.writeFloat(getWapVersion());
                    samsungFile.writeUTF(getDataProtocol());
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }finally {
            try {
                samsungFile.close();
            }catch (IOException exc){
                //
            }
        }

    }

@Override
    public CellularPhone readFromFile(int imei) {
        Samsung samsung=new Samsung();
        RandomAccessFile samsungFile= null;

        try {
            samsungFile= new RandomAccessFile(new File("samsung.txt"),"r");
            try {
                samsungFile.seek((imei-1)*recordSize());
                samsung.setImei(samsungFile.readInt());
                samsung.setModel(samsungFile.readUTF());
                samsung.setNetwork(samsungFile.readUTF());
                samsung.setWapVersion(samsungFile.readFloat());
                samsung.setDataProtocol(samsungFile.readUTF());
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return samsung;
    }

    private long recordSize(){
        return (long)(4+4+((25+ 10+10)*2));
    }
}
