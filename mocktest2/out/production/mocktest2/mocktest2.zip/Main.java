/**
 * Created by Khalin on 11/18/2016.
 */
public class Main {

public static void showPhoneDetails(CellularPhone[] cellularPhone){

for(int count=0;count<cellularPhone.length;count++){
    System.out.println(cellularPhone[count]);
}


}
    public static void main(String [] args){
            CellularPhone cellularPhone= new CellularPhone();
            Samsung samsung= new Samsung();
        Nokia nokia= new Nokia();
   //System.out.println(nokia);
            CellularPhone[] phone= new CellularPhone[3];

        //samsung.initializeToFile();

        Samsung samsung1= new Samsung(1001,"Galaxy Note7","Dutty digicel",2,"LTE");
        samsung1.writeToFile();
        System.out.println(samsung1.readFromFile(1001));
                phone[0]= new CellularPhone();
                phone[1]= new Samsung();
                phone[2]= new Nokia();
//showPhoneDetails(phone);



    }

}
