/**
 * Created by Khalin on 9/16/2016.
 */
public class Main {
    public static void main(String[] args){
        Member mem1= new Member();
        System.out.print(mem1);

    }
}
