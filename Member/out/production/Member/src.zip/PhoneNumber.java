/**
 * Created by Khalin on 9/16/2016.
    1501396

 */
public class PhoneNumber {

    private String areaCode;
    private String exchange;
    private String line;

    public PhoneNumber() {
        areaCode = "000";
        exchange = "000";
        line = "0000";
    }

        public PhoneNumber(String areaCode, String exchange, String line){
            this.areaCode=areaCode;
            this.exchange=exchange;
            this.line=line;
        }

        public PhoneNumber(PhoneNumber obj){
            areaCode=obj.areaCode;
            exchange=obj.exchange;
            line=obj.line;
    }

    public String toString(){
        String out;
        out="("+areaCode+")"+ exchange + "-" + line;
        return out;
    }

    public String getAreaCode() {
        return areaCode;
    }

    public String getExchange() {
        return exchange;
    }

    public String getLine() {
        return line;
    }

    public void setAreaCode(String areaCode) {
        this.areaCode = areaCode;
    }

    public void setExchange(String exchange) {
        this.exchange = exchange;
    }

    public void setLine(String line) {
        this.line = line;
    }
}
